# Energy Forecasting — Source Code

Self-contained bundle for the LUISS × Enel project: hourly household electricity
forecasting with four model families on a leakage-safe pipeline.

## Python and library versions

- Python **3.11**
- All package versions are pinned in [`requirements.txt`](requirements.txt).

## How to read the results (fast)

The notebook ships with every output pre-rendered, so no retraining is needed
to read the deliverable:

```bash
pip install -r requirements.txt
```

Then open [`main.ipynb`](main.ipynb) in Jupyter Lab or VS Code and *Run All*
(~10 seconds; only loads tracked artifacts from `data/`, `results/`,
`figures/`).

## How to retrain everything from scratch (~90 minutes total)

Each script is self-contained and run in the order indicated by its
numeric prefix:

| # | Script | What it does | Wall-clock |
|---|---|---|---|
| 01 | `01_build_features.py` | UCI raw → `data/features.parquet` (31 leakage-safe features) | ~30 s |
| 02 | `02_fetch_weather.py` | Paris–Montsouris weather → `data/paris_montsouris_weather.parquet` | ~10 s |
| 03 | `03_cache_eda_summary.py` | EDA summary JSON + seasonality plot series → `results/eda_*` | ~20 s |
| 04 | `04_run_naive_baselines.py` | 3 persistence baselines, 6 folds each | ~30 s |
| 05 | `05_run_xgboost.py` | XGBoost, 6 folds | ~1 min |
| 06 | `06_run_sarima.py` | SARIMA(1,1,1)(1,1,1,24), 6 folds | ~14 min |
| 07 | `07_run_lstm_and_gru.py` | LSTM + GRU, 6 folds each | ~45 min |
| 08 | `08_run_xgboost_with_weather.py` | XGBoost on features + weather, 6 folds | ~1 min |
| 09 | `09_run_stacking.py` | Ridge meta-learner over the 4 base models | ~30 s |
| 10 | `10_run_dm_test_and_segments.py` | Diebold–Mariano + per-segment MAE | ~5 s |
| 11 | `11_aggregate_leaderboard.py` | Aggregate per-fold CSVs → `results/leaderboard.csv` | ~2 s |
| 12 | `12_build_technical_report.py` | Regenerate technical report PDF | ~5 s |
| 13 | `13_build_presentation.py` | Regenerate the presentation deck | ~3 s |

Outputs land in `results/` (CSV / JSON) and `figures/` (PNG).

## Layout

```
.
├── README.md                    ← this file
├── requirements.txt             ← pinned Python deps
├── conf.yaml                    ← single source of truth (target, frequency, fold config)
├── main.ipynb                   ← deliverable notebook (entry point)
├── 01_*.py … 13_*.py            ← numbered, role-named scripts in chronological run order
├── energy_forecasting/          ← supporting Python package imported by the scripts
├── data/                        ← features.parquet + paris_montsouris_weather.parquet
├── results/                     ← per-fold CSVs + leaderboard.csv + DM matrix + EDA JSON
└── figures/                     ← leaderboard, per-segment, AvP plots
```
