"""Streamlit app for the Energy Forecasting deliverable.

Minimal multi-page UI:
- Home: project summary and `results/leaderboard.csv`
- EDA: show `results/eda_summary.json` and seasonality figures
- Predictions: pick model + fold, show actual vs predicted and allow CSV download
- Figures: show static PNGs from `figures/`

Run with: `streamlit run streamlit_app.py` from project root.
"""
from pathlib import Path
import json

import pandas as pd
import plotly.express as px
import streamlit as st

BASE = Path(__file__).resolve().parent
RESULTS = BASE / "results"
FIGURES = BASE / "figures"
DATA = BASE / "data"

st.set_page_config(page_title="Energy Forecasting", layout="wide")

st.sidebar.title("Navigation")
page = st.sidebar.radio(
    "Go to", ["Home", "EDA", "Predictions", "Metrics", "Figures", "About"]
)


def load_leaderboard() -> pd.DataFrame:
    p = RESULTS / "leaderboard.csv"
    if p.exists():
        return pd.read_csv(p)
    return pd.DataFrame()


def list_prediction_files(model_prefix: str):
    files = sorted(RESULTS.glob(f"{model_prefix}_predictions_fold*.csv"))
    return files


def read_prediction(path: Path) -> pd.DataFrame:
    return pd.read_csv(path, parse_dates=True)


def list_fold_results() -> list[Path]:
    return sorted(RESULTS.glob("*_fold_results.csv"))


def make_zip_bytes(paths: list[Path]) -> bytes:
    import io, zipfile

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for p in paths:
            try:
                zf.writestr(p.name, p.read_bytes())
            except Exception:
                # skip unreadable
                pass
    return buf.getvalue()


def leaderboard_cards(df: pd.DataFrame, *, top_n: int = 4) -> None:
    if df.empty:
        st.info("No leaderboard.csv found in results/")
        return

    top = df.sort_values("MAE_mean").head(top_n).reset_index(drop=True)
    cols = st.columns(len(top))
    palette = ["#1f77b4", "#2ca02c", "#ff7f0e", "#9467bd"]
    for idx, row in top.iterrows():
        accent = palette[idx % len(palette)]
        with cols[idx]:
            st.markdown(
                f"""
                <div style="border:1px solid #d0d7de;border-top:5px solid {accent};"
                "border-radius:16px;padding:14px 16px;background:linear-gradient(180deg,#fff,#fbfdff);"
                "box-shadow:0 1px 4px rgba(0,0,0,0.06);min-height:190px;">
                  <div style="font-size:0.82rem;color:#6e7781;text-transform:uppercase;letter-spacing:0.05em;">Model</div>
                  <div style="font-size:1.15rem;font-weight:700;color:#111827;margin-bottom:8px;">{row['model']}</div>
                  <div style="font-size:2rem;font-weight:800;color:{accent};line-height:1;">{row['MAE_mean']:.3f}</div>
                  <div style="font-size:0.88rem;color:#57606a;margin-top:4px;">MAE mean ± std: {row['MAE_std']:.3f}</div>
                  <div style="margin-top:10px;font-size:0.9rem;color:#24292f;">RMSE: {row['RMSE_mean']:.3f}</div>
                  <div style="font-size:0.9rem;color:#24292f;">WAPE: {row['WAPE_mean']:.3f}</div>
                  <div style="font-size:0.9rem;color:#24292f;">MASE: {row['MASE_mean']:.3f}</div>
                </div>
                """,
                unsafe_allow_html=True,
            )


def render_metric_bars(df: pd.DataFrame) -> None:
    if df.empty:
        return
    fig = px.bar(
        df.sort_values("MAE_mean"),
        x="model",
        y=["MAE_mean", "RMSE_mean", "WAPE_mean"],
        barmode="group",
        labels={"value": "score", "model": "model"},
        title="Cross-fold mean scores",
    )
    fig.update_layout(height=420, legend_title_text="Metric")
    st.plotly_chart(fig, use_container_width=True)


def render_figure_preview() -> None:
    preview_files = [
        FIGURES / "leaderboard_bar.png",
        FIGURES / "segment_mae_by_dimension.png",
        FIGURES / "xgboost_feature_importance.png",
    ]
    available = [p for p in preview_files if p.exists()]
    if not available:
        return
    st.caption("Selected report figures")
    cols = st.columns(min(3, len(available)))
    for col, img in zip(cols, available):
        with col:
            st.image(str(img), caption=img.name, use_column_width=True)


if page == "Home":
    st.title("Energy Forecasting — Deliverable")
    st.markdown("This interactive viewer exposes precomputed results and figures from the project.")
    lb = load_leaderboard()
    if not lb.empty:
        st.subheader("Leaderboard")
        leaderboard_cards(lb, top_n=min(4, len(lb)))
        render_metric_bars(lb)
        render_figure_preview()
        csv = lb.to_csv(index=False).encode("utf-8")
        st.download_button("Download leaderboard CSV", csv, file_name="leaderboard.csv")
    else:
        st.info("No leaderboard.csv found in results/")


elif page == "EDA":
    st.title("Exploratory Data Analysis")
    eda_json = RESULTS / "eda_summary.json"
    if eda_json.exists():
        with eda_json.open("r", encoding="utf-8") as fh:
            data = json.load(fh)
        st.subheader("EDA summary (JSON)")
        st.json(data)
    else:
        st.info("No eda_summary.json found in results/")

    st.subheader("Seasonality figures")
    for fname in [
        "eda_seasonality_weekly.csv",
        "eda_seasonality_nov2007_hourly.csv",
        "eda_seasonality_june2008_daily.csv",
    ]:
        p = RESULTS / fname
        if p.exists():
            try:
                df = pd.read_csv(p)
                st.write(fname)
                st.line_chart(df.set_index(df.columns[0]))
            except Exception:
                st.write(f"Could not render {fname}")


elif page == "Predictions":
    st.title("Model Predictions")
    models = {
        "lstm": "lstm",
        "gru": "gru",
        "xgboost": "xgboost",
        "xgboost_with_weather": "xgboost_with_weather",
        "sarima": "sarima",
        "stacking": "stacking",
    }
    model_choice = st.selectbox("Model", list(models.keys()))
    files = list_prediction_files(models[model_choice])
    if not files:
        st.info("No prediction CSVs found for that model in results/")
    else:
        file_options = [f.name for f in files]
        sel = st.selectbox("Pick file", file_options)
        p = RESULTS / sel
        df = read_prediction(p)
        st.subheader(sel)
        if "timestamp" in df.columns:
            df["timestamp"] = pd.to_datetime(df["timestamp"]) 
            df = df.sort_values("timestamp")
            fig = px.line(df, x="timestamp", y=[c for c in df.columns if c != "timestamp"], labels={"value":"kW"})
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.write(df.head())
        csv = df.to_csv(index=False).encode("utf-8")
        st.download_button("Download predictions CSV", csv, file_name=sel)


elif page == "Metrics":
    st.title("Metrics & Diagnostics")
    st.markdown("Aggregate per-fold metrics and leaderboard visualizations.")
    # Leaderboard
    lb = load_leaderboard()
    if not lb.empty:
        st.subheader("Leaderboard summary")
        leaderboard_cards(lb, top_n=min(4, len(lb)))
        render_metric_bars(lb)
    else:
        st.info("No leaderboard.csv found in results/")

    # Per-fold results
    st.subheader("Per-fold results")
    folds = list_fold_results()
    if not folds:
        st.info("No *_fold_results.csv files found in results/")
    else:
        selections = st.multiselect("Select result files to compare", [p.name for p in folds], default=[p.name for p in folds])
        chosen = [RESULTS / name for name in selections]
        if chosen:
            df_all = pd.concat((pd.read_csv(p) for p in chosen), ignore_index=True)
            st.write(df_all.head())
            # boxplot for MAE per model
            if "MAE" in df_all.columns:
                fig2 = px.box(df_all, x="model", y="MAE", points="all")
                st.plotly_chart(fig2, use_container_width=True)

    # Download bundle
    st.subheader("Download bundle")
    bundle_files = st.multiselect("Pick files to include in ZIP", [f.name for f in sorted(list(RESULTS.iterdir()) + list(FIGURES.iterdir()))])
    if bundle_files:
        paths = [RESULTS / name if (RESULTS / name).exists() else FIGURES / name for name in bundle_files]
        zip_bytes = make_zip_bytes(paths)
        st.download_button("Download ZIP", zip_bytes, file_name="energy_forecasting_bundle.zip")

elif page == "Figures":
    st.title("Figures")
    imgs = sorted(FIGURES.glob("*.png"))
    if not imgs:
        st.info("No PNGs found in figures/")
    else:
        for img in imgs:
            st.image(str(img), caption=img.name, use_column_width=True)


elif page == "About":
    st.title("About")
    st.markdown("""
    - Project: Energy Forecasting
    - Use the scripts `01_*.py` ... `13_*.py` to regenerate artifacts.
    - This app reads precomputed CSVs and figures in `results/` and `figures/`.
    """)
    st.markdown("---")
    conf_path = BASE / "conf.yaml"
    st.write("Configuration default path:", str(conf_path))
    if conf_path.exists():
        try:
            conf_text = conf_path.read_text(encoding="utf-8")
            st.subheader("conf.yaml")
            st.code(conf_text, language="yaml")
        except Exception:
            st.write("Could not read conf.yaml")
    else:
        st.info("No conf.yaml found at project root")
